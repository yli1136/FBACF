function seqs=configSeqs_demo_for_FBACF

Gull1 = {struct('name','Gull1','path','.\seq\Gull1\','startFrame',1,'endFrame',120,'nz',5,'ext','jpg','init_rect',[0,0,0,0])};

seqs = Gull1;
